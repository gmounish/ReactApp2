const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    "/was",
    createProxyMiddleware({
      target: "https://rdd-qa-east1.ebiz.verizon.com",
      changeOrigin: true,
      headers: {
        Authorization: "Basic TmV0d29yazo1R1JvdXRlcg",
      },
    })
  );
};
