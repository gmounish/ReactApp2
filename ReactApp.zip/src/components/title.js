function Title(prop) {
    const title = prop.title;
    return (
        <div>
            <p>{title}</p>
        </div>
    );
}
export default Title;