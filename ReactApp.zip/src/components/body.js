function Body() {
    const Body = 'Car Body';
    return (
        <div>
            <p>{Body}</p>
        </div>
    );
}
export default Body;